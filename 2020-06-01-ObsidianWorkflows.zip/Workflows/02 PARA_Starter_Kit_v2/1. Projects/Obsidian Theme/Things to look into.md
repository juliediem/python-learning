List:
- New application features and menu
- Focus mode for the current line
- Focus UI for writing