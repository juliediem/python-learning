Tags: [[Email]] [[Marketing]] - [[Audience]] [[Customer]] [[Local]]
Author: [[Seth Godin]]
## Highlights:

With few exceptions, that’s being replaced by a return to clusters.

The cluster might be geographic (they eat different potato chips in Tucscon than they do in Milwaukee) but they’re much more likely to be psychographic instead. What a group of people believe, who they connect with, what they hope for…

The minimal viable audience concept requires that you find your cluster and overwhelm them with delight. Choose the right cluster, show up with the right permission and sufficient magic and generosity and the idea will spread.
