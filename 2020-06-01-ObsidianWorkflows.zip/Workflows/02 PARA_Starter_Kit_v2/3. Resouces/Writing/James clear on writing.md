A few tips on how to be a better writer:
- write about what fascinates you
- make one point per sentence
- use stories to make your point
- cut extra words like “really” and “very”
- read the whole thing out loud
- post publicly (you’ll try harder when you know others will read it)

And finally, be more thoughtful about what you consume. The quality of ideas you put in determines the quality of ideas you put out.