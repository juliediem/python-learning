## Ingredients   
- 6 slices bread
- 1/2 onion, grated
- 1/4 cup shredded Swiss cheese
- 1/2 cup milk
- 2 eggs
- 1/2 teaspoon dry mustard
## Directions    
- Preheat oven to 375 degrees F (190 degrees C). 
- Lightly grease 12 muffin tins.
- Trim or cut bread into circles. 
- Place circles in bottom of muffin tins. 
- Distribute the onion and shredded cheese evenly between the muffin tins.
- In a medium bowl, combine milk, eggs, mustard and pepper. 
- Divide between the muffin tins. 
- Bake in preheated oven for 20 minutes, or until a toothpick inserted into the center of a quiche comes out clean.

