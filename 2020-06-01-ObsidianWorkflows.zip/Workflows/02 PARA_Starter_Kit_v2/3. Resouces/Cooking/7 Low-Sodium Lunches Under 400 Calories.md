**1. [SLOW COOKER CHICKEN ADOBO WITH PINEAPPLE](https://blog.myfitnesspal.com/slow-cooker-chicken-adobo-with-pineapple/) MYFITNESSPAL'S RECIPES**

Nutrition (per serving): Calories: 340; Total Fat: 14g; Saturated
Fat: 4g; Monounsaturated Fat: 6g; Cholesterol: 231mg; Sodium: 383mg;
Carbohydrate: 6g; Dietary Fiber: 2g; Sugar: 3g; Protein: 44g

**2. [SALMON AND SPINACH FRITTATA](https://blog.myfitnesspal.com/salmon-and-spinach-frittata/) MYFITNESSPAL'S RECIPES**

Nutrition (per serving): Calories: 152; Total Fat: 6g; Saturated
Fat: 1g; Monounsaturated Fat: 1g; Cholesterol: 94mg; Sodium: 176mg;
Carbohydrate: 6g; Dietary Fiber: 1g; Sugar: 5g; Protein: 20g


**3. [THAI CURRY TOFU OVER SWEET POTATOES](https://blog.myfitnesspal.com/thai-curry-tofu-over-sweet-potatoes/) MYFITNESSPAL'S RECIPES**

Nutrition (per serving): Calories: 397; Total Fat: 17g; Saturated
Fat: 12g; Monounsaturated Fat: 1g; Cholesterol: 0mg; Sodium: 379mg;
Carbohydrate: 48g; Dietary Fiber: 11g; Sugar: 19g; Protein: 16g

**4. [BARLEY AND PROVENCAL VEGETABLES IN VINAIGRETTE](https://blog.myfitnesspal.com/barley-and-provencal-vegetables-in-vinaigrette/) MYFITNESSPAL'S RECIPES**

Nutrition (per serving): Calories: 284; Total Fat: 8g; Saturated
Fat: 2g; Monounsaturated Fat: 4g; Cholesterol: 5mg; Sodium: 387mg;
Carbohydrate: 43g; Dietary Fiber: 10g; Sugar: 6g; Protein: 11g

**5. [SALMON CAKES ON MIXED GREENS](https://blog.myfitnesspal.com/salmon-cakes-on-mixed-green-salad) MYFITNESSPAL'S RECIPES**

Nutrition (per serving): Calories: 250; Total Fat: 12g; Saturated
Fat: 1g; Monounsaturated Fat: 3g; Cholesterol: 0mg; Sodium: 156mg;
Carbohydrate: 11g; Dietary Fiber: 3g; Sugar: 4g; Protein: 23g

**6. [DUKKAH-CRUSTED CHICKEN SHAWARMA SALAD WITH TAHINI RANCH](https://blog.myfitnesspal.com/dukkah-crusted-chicken-shawarma-salad-with-tahini-ranch/) MYFITNESSPAL'S RECIPES**

Nutrition (per serving): Calories: 329; Total Fat: 15g; Saturated
Fat: 2g; Monounsaturated Fat: 8g; Cholesterol: 41mg; Sodium: 352mg;
Carbohydrate: 31g; Dietary Fiber: 6g; Sugar: 6g; Protein: 21g

**7. [CREAMY CAULIFLOWER AND CARROT SOUP](https://blog.myfitnesspal.com/creamy-cauliflower-and-carrot-soup/) MYFITNESSPAL'S RECIPES**

Nutrition (per serving): Calories: 263; Total Fat: 15g; Saturated
Fat: 3g; Monounsaturated Fat: 9g; Cholesterol: 7mg; Sodium: 238mg;
Carbohydrate: 24g; Dietary Fiber: 7g; Sugar: 12g; Protein: 11g
