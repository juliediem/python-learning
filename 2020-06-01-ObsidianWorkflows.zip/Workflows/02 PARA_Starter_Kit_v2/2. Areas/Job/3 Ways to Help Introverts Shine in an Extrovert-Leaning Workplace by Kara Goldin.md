https://www.entrepreneur.com/article/342450

while about half of the general population are extroverts, up to 96 percent of managers and executives display extroverted traits, reveals a study published in Industrial and Organizational Psychology. Other research estimates that up to 70 percent of C-suite executives are extroverts.

In contrast, anywhere between 16 and 50 percent of the population are considered introverts \-- people who find "alone time" energizing and might feel drained in social settings
