- Tags: [[Project Management]] [[Productivity]] [[Notion]] [[ClickUp]] [[Todoist]] [[Drafts]]
- ## References/Ideas
    - Refererences: 
        - [[Project Management]] [[=Draft= 5 Projects Rules]] [[ClickUp]] [[Notion]] [[Todoist]]
    - Mention/Search:
        - 
- # Draft
    A little while ago I was feeling overwhelmed for what seemed no apparent reason. I had a lot of projects going on, but nothing out of the ordinary. I had 3-4 projects I was tracking. I was looking at my schedule weekly. Everything should be fine normally. But then I started to feel the pull of trying new application. That's not nescessarily a good default really to go chase the "oh shiny" but if I let myself experiement, fully knowing about it, I often end up finding the actual pain point to fix. So I tried a bunch of new apps and ways to try to fix the problem I was having. Then I realized what I was wanting out of all of those and what I was trying to achieve. 
    