Guest: [[James Clear]] [[Self-Development]] - [[Habits]] [[System]]
Podcast: [[Make Sense With Sam Harris]] 

## Highlights:

Habits are often heavily influenced by the environnement that we're in, those environnement link into the habits.

Habit are solution to reccuring problems in your life.

Difference between good habits and bad habits:
- missalignement between the short outcome and the ultimate outcome, bad habits are often immeditately enjoyable vs long term return
- the cost of your bad habit are in the future and the cost of your good habit are in the present

Most of your outcome in life are lagging measures of your habits

Habits are not a finish line to be crossed
