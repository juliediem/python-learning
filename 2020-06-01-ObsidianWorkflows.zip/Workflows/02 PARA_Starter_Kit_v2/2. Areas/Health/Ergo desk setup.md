Desk and chair

adjust your chair in height untill the elbow are bend to 90o

-   might require a foot step if then you don't touch down

adjust monitor, need to be arms length and the top of the screen is at
eye level

for 2 monitor you want one straight in front and the other at an angle

if you use both equaly make them so you're in the middle of the 2

for kb + mouse, the keyboard should be where you hands end up when you
sit

mouse should be close by the keyboard, you don't want to have to move

Other
-   get up every hour
