Tags: [[Podcast]] [[Finance]] - [[Investing]] [[Budget]]
Guest: [[Ramit Sethi]]
Podcast: [[You Need a Budget Podcast]] 

## Highlights:

Good investment advice are timeless, they stay the same

=="Spend extravagantly on the things you love as long as you cut cost mercilessly on the things you don't"==

We all have a dial, a money dial, things like relationship, travel, convenience

What would it feel like to spend 2x or even 3x the money on those 

you want to go from "hot" emotion like anxiety and remorse to "cold" emotion like I decided to spent on this, I want to spend on this dial 

instead of approaching money from a scarcity perspective use it as a tool

splurge on things to fix a problem you have

you shouldn't judge how people spend their money but be curious about the reason behind it

instead of judging when you hear someone spent crazy money on something 

try to come up with at least 10 reasons why 

craft your rich life, there's some area in your life that shouldn't have budget

have some areas in your life where you KNOW and PLAN you will overspend. Those place that make your life better

overspending is not going over but going extravagant
