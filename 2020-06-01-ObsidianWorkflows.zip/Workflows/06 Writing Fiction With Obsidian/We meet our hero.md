tags: #carl #risingaction #introduction


---


# We Meet Our Hero

It was a dark and stormy night when Carl got the call from the Commissioner. "Carl!" cried the tinny voice on the other end of the telephone, "Don't you know you should never start a story by describing the weather?"

Carl was undaunted. His tough green skin and powerful shell would protect him from the worst clichés. A turtle was just the right man for this job. 




