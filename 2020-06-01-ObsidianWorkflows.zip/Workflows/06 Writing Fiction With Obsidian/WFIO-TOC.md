*(Editor's note: only the first link in this file will work, the rest are there as examples.)*

## Act 1
### Chapter 1

[[We meet our hero]]
[[Save the cat!]]

### Chapter 2

[[The villain arrives]]


## Act 2
[[Further Complications Arise]]
The hero shows up <= turn this into a link when you're ready to write this scene
- maybe we need some more action here?
- what about the love interest? [[A Note Elsewhere About The Love Interest]]

## Act 3

[[Happy ending!]]
- or is it? [[A Note Elsewhere About A Sequel]]