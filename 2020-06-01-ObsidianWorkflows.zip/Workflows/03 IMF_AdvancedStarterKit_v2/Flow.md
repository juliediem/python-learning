# Flow
The concept of flow has changed my life. For more on it for now, click here: [[FlowCreation TOC]]

When you get [[Reps]] of [[Deliberate Practice]] and gain a certain level of competence, then getting more reps creates a [[Positive Feedback Loop]] of deeper focus and [[Flow]] experiences.

---
tags: #concepts 
links: [[Concepts MOC Examples]]
