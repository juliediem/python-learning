# Cobwebs into Cables
Turning cobwebs into cables is a metaphor for strengthening neural connections through [[Reps|repetitions]].

---
tags: #pd #habits #concepts
links:  [[000 Index|Index]], [[Concepts MOC|Concepts]], [[IMF START]]