tags: #journal #compilation #IMF

Here's an example of when I talked about hormesis and micro-workouts

![[201912231334 My 2019 Review, embed example]]

What's interesting is that I actually mentioned micro workouts a couple months earlier and just forgot.

![[201910109999 example]]


