tags: #books #TOC #MOC
Index: [[000 Index|Index]], [[040 Interests MOC|Interests]]

---
## Main Book Categories
[[145500000890 Books I Have Read]]
[[145500000790 Books Purgatory List]]
[[145500000690 Books Unread I Own]]
[[145500000001 Book_Name - Author_Name_TEMPLATE]]

## Main Book Tags
#books
#books100

### Descriptor Book Tag: Choose one per book
1. #booksToRead 
2. #booksNotToRead
3. #booksToFinish
4. #booksNotToFinish
5. #booksToBrowse
6. #booksToRevisit
7. #booksToReference
8. #booksFinished

## Some Notable Books



## Temp Tasks - No rush on these
### Temp: Notes to Extract from the Kindle

### Temp: Notes to Extract from Audible

### Temp: Notes to Extract from iBooks

### Temp: Notes to Extract from the physical book itself