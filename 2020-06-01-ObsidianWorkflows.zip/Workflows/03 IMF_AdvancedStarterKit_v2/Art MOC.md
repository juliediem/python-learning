tags: #MOC #Movies; #TV; #music; #songs; #songs100; #songs250
links: [[040 Interests MOC|Interests]]

---
# Inputs, Media, Consumption, Art

==Note: The linked notes are not provided==

## Books
- [[Books Example MOC]]

## Movies
[[146600000890
[[201208069999 40 Movies in 40 Days]]

## TV
[[146600000790

## Plays
[[146600000690

## Songs
[[146600000590 List - Favorite Songs]]