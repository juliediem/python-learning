# Spatial Context
The ancients had to rely on their memories to hold onto information. They developed mind palaces and other mneumonic devices. Central to their efforts of recalling information was placing their atoms of information into a Spatial Context. It turns out Spatial Context is a very strong form of memory. 

---
tags: #pkm
links: [[IMF MOC]], [[Benefits of IMF]]