tags: #essays #blogs #MOC #blog
links: [[060 Writings MOC|Writings]] 

---
# Essays
I'm calling this `Essays` and not `Blogs` because I value the explorative properties of an essay, in contrast to a blog's more "I have answers" attitude. But yes, this includes `blogs` too.


## List of Essays and Blogs
This is really just a chronological content map for essays and blogs. 

### 2017
- [[201709099995 Example Blog]]

### 2016
- [[201601191914 Example Blog]]

### 2015
- [[201511210738 Example Blog]]
- [[201510130728 Example Blog]]
- [[201509171430 Example Blog]]
- [[201509131345 Example Blog]]
- [[201509091057 Example Blog]]
- [[201509091056 Example Blog]]
- [[201509091017 Example Blog]]

### 2014
- [[201412161821 Example Blog]]
- [[201412161803 Example Blog]]
- [[201411011713 Example Blog]]

### 2013
- [[201301291949 Example Blog]]

### 2009 - 2010
- [[201009049999 Example Blog]]
