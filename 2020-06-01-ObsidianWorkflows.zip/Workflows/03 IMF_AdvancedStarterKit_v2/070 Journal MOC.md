tags: #journal #reflections #faves
links: [[000 Index|Index]], [[070 Journal MOC|Journal]], [[060 Writings MOC|Writing]]

# Journal MOC
This is private. I would suggest organizing by chronology, and embedding snippets of your favorite journals in bite-size compilations.

## Chronology
### 2020
[[2020 Journal Compilation]]
### 2019
[[2019 December Journal Compilation]]

### 2018
### 2017
### 2016
### 2015
### 2014
### 2013
### 2012
### 2011
### 2010
### 2009
### 2008
### 2007
### 2006
### 2005
### 2004