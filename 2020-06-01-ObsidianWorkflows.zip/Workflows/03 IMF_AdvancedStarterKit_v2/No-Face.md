# No-Face
*The self-destructive primal tension everybody harbors.*  

No-Face is a spirit in the 2001 Japanese animated film Spirited Away. According to Miyazaki, No-Face is “the libido everybody secretly harbors.” 

If "you are what you eat," No-Face eats the emotions of whatever is in front of it. It's reactive, not proactive.

No-Face is aroused by (and absorbes) primal tension and aggressive drives, easily becoming a self-perpetuating feedback loop of hot emotions. It's essentially Freud's [[The Id|Id]].

## Handling No-Face
`Do Not Engage!` — When the primal part of people take over, it's like they become No-Face. Do not perpetuate the aggression No-Face feeds off of. No-Face is best deflated by choosing not to respond aggressively (ie, sinking to its level), but rather by calling upon your reserves of discipline to enter a mindset of restraint and non-reaction; benevolence and patience—with an eye towards the well-being of the attacker while still holding your own.

In this way, you are not feeding the libido, but letting itself wear itself out. Just as No-Face's aggressions are dissipated by Chihiro in Spirited Away.
 
 There is an art to handling self-perpetuating aggressiveness. Look to [[Aikido]] for more insights into deflecting and dissipating an attacker's energy.

## Related
| [[Aikido]] | [[The Id]] | 

(previous thoughts now outdated: is organum indifferens, neither good nor evil; an emotion mirror, it becomes its environment)

---
links: [[Concepts MOC]]

