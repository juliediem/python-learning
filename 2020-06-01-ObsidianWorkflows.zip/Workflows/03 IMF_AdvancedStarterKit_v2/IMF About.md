# About IMF
The goal of IMF is to enhance your experience of working with your digital library. It provides flexibility, longevity, and a bevy of other [[Benefits of IMF|Benefits]].

If you'd got any value out of this or would like contribute to this project, please reach out on discord at `nickmilo#6327` or email `nickmilo@protonmail.com`.

-nickmilo

---
tags: #pkm #IMF
links: [[IMF START]], [[IMF MOC]]
