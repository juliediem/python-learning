tags: #MOC #projects #ideas #idea #IMF
links: [[000 Index|Index]], [[100 Ideas MOC|Ideas]], [[100 Projects MOC|Projects]]

---
# Ideas MOC
These are just ideas. If I do more with them, they can graduate to "Projects".

## List of Ideas

## Unsorted Ideas

## Film Ideas 

## Book Ideas

## Course Ideas

## Web Ideas
