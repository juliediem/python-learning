### Obsidian requests
- [x] renaming filenames doesn't successfully update all the links with the [[Note|Wikipedia-Note Reference]] notation. It updates some, but not all. [[TODO]]
- [ ] really missing the ability to highlight text and hit a hotkey to instantly add bullets/numbers to each new line. In The Archive this is called "Switch List Type" and is cmd+ctrl+t
- [X] File Explorer functionality
- [x] Find function within the document only highlights the first instance. The buttons for Prev, Next, and All are not working.

tags: #obsidian 