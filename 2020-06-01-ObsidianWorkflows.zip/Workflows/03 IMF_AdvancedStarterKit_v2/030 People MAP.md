tags: #people #MOC #family #friends #pings
links: [[000 Index|Index]], [[030 People MAP|People]]

# People MOC
Welcome to the People MOC. This is about having a place to honor the importance of the people in my life by jotting down notable information. 

==NOTE: These use the Date Time Unique ID's (DTIDs) in the form of YYYYMMDDHHmm. None of these will link to anything in this starter kit. I only chose not to delete them to provide an example of how they would look.==

### Top People Lists
YOUR INDUSTRY People [[201610011238]] « « « ==DTID Links like this won't work==
Birthdays
People to Ping

### Broad Categories of Interaction
Unsorted People Catch-All [[201903261733]] #people

#### Family
Family [[201903261157]] #family 

#### ENT
YOUR INDUSTRY Unsorted [[201603261741]] #ent
HBO Applicants [[201702250907]]  #ent #HBO 
YOUR INDUSTRY Outreach [[202001140755]] 

#### Friends
High School [[201504061959]] #highSchool 
College [[201504081833]] #college 
NYC [[201503261735]] #nyc #pdn #HBO

#### Other
Notable People in History [[201408231536]]


### Templates
You might want certain templates for key information depending on how much you'll use your digital library as a relationship manager. 


