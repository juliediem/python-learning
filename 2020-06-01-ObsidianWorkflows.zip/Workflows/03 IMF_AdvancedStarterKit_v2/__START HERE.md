First, make sure you're using the Dark Theme (or switch themes)
In the File explorer, select "Sort by file name (A to Z)"
Go to the introduction: [[IMF START]]


Disclaimer: If you are completely new, ignore all of this and just start making notes. Maybe come back after you have at least 100 notes.


---
Release notes for v2
- Added 37 additional notes
- Overall tidying
- Changed acronym to IMF
- Added fluid frameworks to the lexicon
- Added an MOC for the IMF that includes areas of future commentary for subsequent versions
- Added commentary on MOCs
- Added examples of different MOCs looking at the same material from different perspectives
- Added commentary on why fluid categories are good
- Started an FAQ

Likely in v3
- Use cases for students
- Deeper look into a projects
- Hidden software lock-in 
- Expanded commentary and use cases for fluid frameworks
- Commentary on future proofing, lock in, the temporal context, UIDs
- Zettelkasten info

---

modified: 2020-05-24

