tags: #stories #MOC
links: [[060 Writings MOC|Writings]] 

---
# Stories
Welcome to the Stories MOC. The idea here is that I have a spot to easily collect and reference stories in my life. They are for hip pocket conversations, potential speeches, and for general memories.

==Note: The links won't work since the associated notes are not provided in the starter kit.==

## Story Lists
My List of Stories [[201412101836 Example]] - transfer this list here
Story File [[201412131846 Example]] 
[[Dreams MOC Example]]
[[Hip Pocket MOC Example]]