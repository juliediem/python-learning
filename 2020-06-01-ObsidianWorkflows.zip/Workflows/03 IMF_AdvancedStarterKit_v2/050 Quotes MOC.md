tags: #quotes #MOC
links: [[000 Index|Index]], [[050 Quotes MOC|Quotes]]

---
# Quotes MOC
Welcome to your "commonplace book" of quotes. Try clicking on #quotes100 to see a couple results. 

==Note: The majority of links and tags won't work since the associated notes are not provided in the starter kit.==

[[Tidbits MOC]]
[[Quips MOC]]

## Some Categories
#ancients
#quips
#quotes100
#quotes250

### Health
#onHealth
#onNutrition #onDiet 
#onExercise

### Life & Death
#onLiving
#onDying
#onLegacy

### People
#onPeople
#onLeadership

### Personal Development & Virtues
#onAttitude #onBelief #onCourage
#onAction #onDoing #onStarting
#onPerseverance #onToughness
#onReps #onPractice #onExcellence #onLuck
#onIntegrity

### Planning and Strategy
#onGoals