tags: #Confucianism 
links: [[040 Interests MOC|Interests]]

---
# Confucianism