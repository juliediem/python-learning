tags: #MOC #finances #accounts #realestate
links: [[000 Index|Index]], [[085 Finances MOC|Finances]] 

# Finances MOC
You might want to some of this info out of your digital library. Some areas, like managing taxes, is better with computer folders, PDFs, and spreadsheets. However, there are some areas of finances that do work well within the digital library.

## Auto Info
Auto Ledger

## Insurance Info
Insurance Ledger

## Healthcare Info
Health Insurance Ledger
General Care Ledger
Prescription Ledger
Eye Care Ledger
Dental Ledger

## Tax Info
Tax Ledger

## CC Info & Bills
Annually Recurring Bills
List of Credit Cards
ID Ledger

## Real Estate Info
CCCH

## Stock Info
Traditional IRA - research
Roth IRA

## Account Info
Username Doc from 2009, dusty
FedEx Account Numbers
