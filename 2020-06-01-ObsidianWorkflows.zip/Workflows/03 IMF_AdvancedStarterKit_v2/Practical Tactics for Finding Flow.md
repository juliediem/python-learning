# Practical Tactics for Finding Flow
1. There are things that get in the way of flow. We'll call those [[Flow Stoppers]].
2. With each Flow Stopper, there are solutions to get through them. We'll call those [[Solutions to Flow Stoppers]].

---
toc: [[FlowCreation TOC]]
