tags: #MOC #projects #ideas #IMF
Index: [[000 Index|Index]], [[100 Ideas MOC|Ideas]], [[100 Projects MOC|Projects]] 

# PROJECTS
Welcome to the Projects TOC. These are "Ideas that have graduated." This is about having a place to reference creations (outputs) like books, mini-books, manuals, film projects, etcetera. 

## Projects 
- [[FlowCreation TOC]] - Here's an example for you
 - your project here
 - your project here

## Dusty Projects
*These projects may have already bit the dust. I'm just keeping track of them here.*
 - your project here
 - your project here
 - your project here
