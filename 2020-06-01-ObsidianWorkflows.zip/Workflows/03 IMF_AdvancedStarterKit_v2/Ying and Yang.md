# Ying and Yang


## Wiki
In Chinese philosophy, yin and yang is a concept of dualism in ancient Chinese philosophy, describing how seemingly opposite or contrary forces may actually be complementary, interconnected, and interdependent in the natural world, and how they may give rise to each other as they interrelate to one another.

The [[Seasons]] are related to Ying and Yang.

---
tags: #mentalModels #concepts
links: [[Concepts MOC]]


