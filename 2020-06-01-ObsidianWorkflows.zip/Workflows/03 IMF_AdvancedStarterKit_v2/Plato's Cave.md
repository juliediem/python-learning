tags: #allegories
links: [[Allegories MOC|Allegories]]

---
# Plato's Cave
This is a placeholder. There is a deeper reality.