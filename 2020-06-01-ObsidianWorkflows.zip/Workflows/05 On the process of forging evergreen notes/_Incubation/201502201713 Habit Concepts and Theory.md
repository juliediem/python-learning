# Habit Concepts and Theory
**"Neurons that fire together fire together” Rick hanson**
 

**"Passing mental states become lasting neural traits” Rick hanson**

Portraits of the mind Carl Schoonover showed pictures and showed how dendrites grow spines for better connections to synapses (confirm "better" connections with Ray). Carl also showed video showing neural networks forming. Now more than ever, we are starting to witness the neural formation of habits.

Fredickson's broaden and build theory (maybe use, need to show the relationship between the power and clarity of the negative emotions and the softer more nuanced aspects of he positive emotions.

Use her 10 positive emotions as a quick framework to reference.

Habits quote by William James

Rick hanson's recommendation is simple and powerful. Cementing powerful emotions.

Change your mind to change your brain to change your mind.

**My contribution**: A habit has always been so fascinating to me. A habit is a mirror, it gives what you give it, and what you were given is what you'll give. It's the immediate expression of the law of cause and effect. Just like newtons law of conservation states that for every action there is an equal and opposite reaction; so with habits are that for every action, taking the same action again will require less effort. Neural connections were made and repeated actions optimize them. They become more efficient. We can only surmise as to why, but to me it has clear evolutionary advantages. Any action we take burns calories and uses either our physical muscles, our mental muscles (like the anterior cingulate cortex, which is a crucial player in willpower management), or both. By making a repeated action easier, less energy is used, less willpower is required, and fewer calories are burned—all of which lead to a better chance of survival. 

#Writings2015 #Journal #FAVES #AQ #Blog #WritingsDraftsApp