tags: #habits 
links: [[010 Mind MOC]]

# Habits MOC
[[The neural formation of habits are additive]]
[[The truest habit metaphors are additive]]